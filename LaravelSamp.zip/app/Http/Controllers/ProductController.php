<?php

namespace App\Http\Controllers;
use App\Product;
use Illuminate\Http\Request;

class ProductController extends Controller
{
    public function index()
    {
        $products = Product::all();
        return view('product', [
            'products' => $products
        ]);
    }
    public function newProduct()
    {
        return view('create-product');
    }
    public function storeProduct(Request $request)
    {
        Product::create([
            'name' => $request->input('productName'),
            'price' => $request->input('price'),
            'quantity' => $request->input('quantity')
        ]);
        return redirect('/product');
    }
    public function updateProduct(Request $request, Product $product)
    {
        $product->fill([
            'name' => $request->input('productName'),
            'price' => $request->input('price'),
            'quantity' => $request->input('quantity')
        ]);
        $product->save();
        return redirect('/product');
    }
    public function editProduct(Product $product)
    {
        return view('/edit-product',[
            'product'=>$product
        ]);
    }
    public function deleteProduct(Product $product)
    {
        $product->delete();
        return back();
    }
}

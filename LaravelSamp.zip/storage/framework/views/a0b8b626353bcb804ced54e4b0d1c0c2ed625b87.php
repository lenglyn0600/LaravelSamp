

<?php $__env->startSection('content'); ?>
<div class="container">
<h3>Add Product</h3>
<form method="POST" action="/product">
<?php echo csrf_field(); ?>
  <div class="form-group">
    <label for="productName">Product Name</label>
    <input type="text" name="productName" class="form-control" id="productName" placeholder="Enter Product Name">
  </div>
  <div class="form-group">
    <label for="price">Price</label>
    <input type="text" name="price" class="form-control" id="price" placeholder="Enter Product Price">
  </div>
  <div class="form-group">
    <label for="quantity">Quantity</label>
    <input type="number" name="quantity" class="form-control" id="quantity" placeholder="Enter Product Quantity">
  </div>
  <button type="submit" class="btn btn-success">Submit</button>
</form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\LaravelSamp\resources\views/create-product.blade.php ENDPATH**/ ?>
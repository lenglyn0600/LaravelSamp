<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>DNSC Seminar</title>
</head>
<body>
hello guys...
</body>
</html><?php /**PATH C:\laragon\www\LaravelSamp\resources\views/samp.blade.php ENDPATH**/ ?>